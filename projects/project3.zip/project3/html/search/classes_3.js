var searchData=
[
  ['stack',['Stack',['../class_stack.html',1,'']]],
  ['stack_3c_20std_3a_3astring_20_3e',['Stack&lt; std::string &gt;',['../class_stack.html',1,'']]]
];
