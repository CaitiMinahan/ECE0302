var searchData=
[
  ['bag',['Bag',['../class_bag.html#aa0427ec49669b3fc881f72db5f4fda8b',1,'Bag']]]
];
